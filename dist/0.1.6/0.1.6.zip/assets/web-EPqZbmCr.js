import{W as n}from"./index-UzF0xg9L.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
