import{W as n}from"./index-DnMuwBT9.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
