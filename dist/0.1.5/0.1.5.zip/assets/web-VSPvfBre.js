import{W as n}from"./index-D53LKMss.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
