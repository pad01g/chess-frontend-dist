import{W as n}from"./index-C3_IO7tz.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
