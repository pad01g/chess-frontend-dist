import{W as n}from"./index--eW-FVv8.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
