import{W as n}from"./index-DOMV2-KT.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
